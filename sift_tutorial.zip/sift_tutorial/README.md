# SIFT feature matching with Caltech101

This tutorial contains a complete worked example followed by student TODOs.
It demonstrates local feature matching, masking, geometric error for a known
transformation, and the limitations of using direct SIFT matches for categories.

## Contents

- `sift_caltech101_tutorial.ipynb`: notebook with saved example outputs.
- `requirements.txt`: Python packages used by the notebook.
- `data/101_ObjectCategories/`: car_side, Motorbikes, and airplanes categories.
- `data/SOURCE.txt`: original CaltechDATA source and download checksum.
- `unknown_images/`: five candidate images for the retrieval experiment.
- `unknown_images_manifest.json`: provenance and descriptions of those candidates.

## Run the notebook

1. Extract the entire ZIP. Do not open the notebook from inside the archive.
2. Use Python 3.11 or 3.12 for a straightforward setup. Open a terminal in the
   extracted `sift_tutorial` folder.
3. Create and activate a virtual environment:

   macOS / Linux:
   ```sh
   python3 -m venv .venv
   source .venv/bin/activate
   ```

   Windows (Command Prompt):
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   ```

4. Install the packages and start Jupyter:
   ```sh
   python -m pip install -r requirements.txt jupyterlab
   python -m jupyter lab sift_caltech101_tutorial.ipynb
   ```
5. Select the environment's Python kernel. The notebook installation cell is
   available if dependencies have not already been installed in that kernel.
   If installation updates already imported packages, restart the kernel.
6. Run the worked example from top to bottom. Complete the TODO lines in the separate student exercise cells afterward.
   Write the short `WRITE YOUR CODE` sections (loading, masking, SIFT extraction,
   ratio filtering, and function reuse), removing each corresponding
   `raise NotImplementedError(...)` line when completed. Replace `...` with your
   image and parameter choices. Plotting and geometric evaluation are provided.
   Complete the observations and comparison table at the end of the exercise.

For VS Code, open this extracted folder and select the `.venv` interpreter as the
notebook kernel. `Path.cwd()` should point to the extracted project folder.
Internet is required for initial package installation; all example images are
included, so no dataset download is needed afterward.

## Interpretation

SIFT computes features without training. Match fractions are not class
probabilities. Similar-car photographs are not confirmed to show the same
individual vehicle. Candidate 01 is a synthetic copy of the reference, so its
success does not establish generalization to new cars. Its transformation is
separate from the notebook's controlled transformation.

The package includes 123 car, 798 motorbike, and 800 airplane photographs, not
all Caltech101 categories. The original dataset ZIP and unrelated project files
are omitted. Preserve source attribution when sharing the teaching materials.
Dataset: https://data.caltech.edu/records/mzrjq-6wc02

## Validation

The worked example is checked from an independent copy of this project with
fresh kernel state. Dependencies are installed before validation, so the setup
installation cell is skipped during that check. Feature counts may vary across
versions. Validation environment: Python 3.9.6, NumPy 2.0.2, Matplotlib 3.9.4,
OpenCV 5.0.0. The dependency ranges permit newer compatible versions.
